"""Serializes COM requests; a hung COM call cannot hang the MCP event loop."""
import asyncio
import json
import os
import sys
from pathlib import Path

class WorkerClient:
    def __init__(self, timeout=45):
        self.timeout = timeout
        self.process = None
        self.lock = asyncio.Lock()

    async def close(self):
        p, self.process = self.process, None
        if p and p.returncode is None:
            p.stdin.close()
            try:
                await asyncio.wait_for(p.wait(), 3)
            except asyncio.TimeoutError:
                p.kill()  # Only our Python worker, never LabVIEW.
                await p.wait()

    async def request(self, method, **arguments):
        async with self.lock:
            try:
                if self.process is None or self.process.returncode is not None:
                    self.process = await asyncio.create_subprocess_exec(
                        sys.executable, '-u', str(Path(__file__).with_name('worker.py')),
                        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                        stderr=None, env=os.environ.copy(), limit=8 * 1024 * 1024)
                payload = json.dumps({'operation': method, 'arguments': arguments}) + '\n'
                self.process.stdin.write(payload.encode())
                await self.process.stdin.drain()
                line = await asyncio.wait_for(self.process.stdout.readline(), self.timeout)
                if not line:
                    raise RuntimeError('COM worker exited without a result.')
                return json.loads(line)
            except asyncio.CancelledError:
                await self.close()
                raise
            except Exception as exc:
                await self.close()
                return {'ok': False, 'code': 'WORKER_FAILED', 'error': str(exc) or type(exc).__name__}
