import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def require_certified(p: Path) -> None:
    manifest = json.loads((ROOT/'config/safe-tests.json').read_text())
    if manifest.get(str(p.relative_to(ROOT))) != digest(p):
        raise PermissionError('EXECUTION_DENIED: only hash-certified arithmetic test VIs may run')
