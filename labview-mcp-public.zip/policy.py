from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'test-vis'

def test_vi(path: str) -> Path:
    p = Path(path)
    if not p.is_absolute():
        raise ValueError('An absolute path is required')
    p = p.resolve(strict=True)
    if not p.is_relative_to(ROOT.resolve()) or p.suffix.lower() != '.vi':
        raise ValueError('Only .vi copies inside test-vis are authorized')
    return p
