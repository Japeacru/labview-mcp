"""Encode native LabVIEW 8-bit indexed pixmaps. Never captures the desktop."""
import struct,zlib,binascii
def png_bytes(data):
    image_type,depth,pixels,mask,palette,rect=data
    if image_type!=0 or depth!=8 or len(mask):raise ValueError('Unsupported native pixmap layout')
    left,top,right,bottom=rect;width=right-left;height=bottom-top;raw=bytes(pixels)
    if not 0<width<=4096 or not 0<height<=4096 or len(raw)%height:raise ValueError('Invalid pixmap dimensions')
    stride=len(raw)//height
    if not width<=stride<=width+4:raise ValueError('Unexpected row padding')
    def chunk(tag,body):return struct.pack('>I',len(body))+tag+body+struct.pack('>I',binascii.crc32(tag+body)&0xffffffff)
    colors=b''.join(bytes([(c>>16)&255,(c>>8)&255,c&255]) for c in palette)
    scan=b''.join(b'\0'+raw[y*stride:y*stride+width] for y in range(height))
    result=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,3,0,0,0))
    return result+chunk(b'PLTE',colors)+chunk(b'IDAT',zlib.compress(scan))+chunk(b'IEND',b''),(width,height)
