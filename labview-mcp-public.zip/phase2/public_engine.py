"""Public Scripting engine bootstrap. Internal G refs remain session-scoped."""
import hashlib,json,re,uuid,shutil
from pathlib import Path
try:
    from .bootstrap_public import PublicBootstrap,ROOT,VARIANT,pythoncom
except ImportError:
    from bootstrap_public import PublicBootstrap,ROOT,VARIANT,pythoncom

class PublicEngine(PublicBootstrap):
    def __init__(self):
        super().__init__();self.workers={}
    def call(self,path,params):
        # This upstream helper has an input and output both named Selector.
        # ActiveX Call resolves the wrong connector when names collide. Rename only
        # the copied helper's input in memory for the call, then restore the label.
        if Path(path).name=='Create Case Structure.vi' and 'Selector' in params:
            label=None
            for c in self.find(path,'Control',0):
                text=self.get('Control','Label',c)
                if self.get('Text','Text',text)=='Selector' and not self.get('Control','Indicator',c):
                    label=text;break
            if label is None:raise RuntimeError('Missing unambiguous Case selector input')
            self.set('Text','Text',label,'MCP Input Selector')
            params=dict(params);params['MCP Input Selector']=params.pop('Selector')
            try:return super().call(path,params)
            finally:self.set('Text','Text',label,'Selector')
        result=super().call(path,params)
        if Path(path).is_relative_to(self.vendor):
            v=self.vi(str(path));v._FlagAsMethod('GetControlValue')
            err=v.GetControlValue('error out')
            if isinstance(err,(tuple,list)) and err[0]:raise RuntimeError(f'{path.name}: {err}')
        return result
    def worker(self,kind,cls,member,write=False):
        key=(kind,cls,member,write)
        if key in self.workers:return self.workers[key]
        tag=hashlib.sha256(repr(key).encode()).hexdigest()[:12]
        prefix='runtime-w' if (self.runtime/'manifest.json').exists() else 'w'
        path=self.work/f'{prefix}-{tag}.vi'
        if not path.exists() or not {'reference','error out'}<=set(self.labels(path)) or not self.find(path,'Property' if kind=='property' else 'Invoke'):
            if path.exists():
                self.references.pop(str(path),None)
                path=self.work/f'{prefix}-{tag}-{uuid.uuid4().hex[:4]}.vi'
            self.blank(path);diagram=self.find(path,'TopLevelDiagram')[0]
            params={'Diagram in':diagram,'Class Name':'VI Server:'+cls,
                'location (0, 0)':(100,200),'reference':0,'error in':0,
                'Inputs':[],'error in (no error)':(False,0,''),'Diagram out':0,
                'Outputs':[],'error out':(False,0,'')}
            if kind=='property':
                row=VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_VARIANT,(member,write))
                params['Properties']=VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_VARIANT,(row,))
                source='Create Property Node.vi';node_class='Property'
            else:
                params['ID String']=member;source='Create Invoke Node.vi';node_class='Invoke'
            self.call(self.vendor/source,params)
            nodes=self.find(path,node_class)
            if len(nodes)!=1:raise RuntimeError(f'Expected one {node_class} in {path}')
            base=self.runtime if (self.runtime/'manifest.json').exists() else ROOT/'test-vis'
            self.call(base/'QuickDropSupport/Wire All Terminals_core.vi',{
                'SelList[]':nodes,'Create constants?':False,'User string':'',
                'error in (no error)':(False,0,''),'changes made?':False,'error out':(False,0,'')})
            v=self.vi(str(path));v._FlagAsMethod('SaveInstrument');v.SaveInstrument(str(path),False,False)
        labels=self.labels(path)
        self.workers[key]=(path,labels)
        return path,labels
    @staticmethod
    def match(name,labels):
        def key(s):return re.sub('[^a-z0-9]','',s.lower())
        if name in labels:return name
        found=[s for s in labels if key(s)==key(name)]
        if len(found)!=1:raise ValueError(f'Cannot resolve {name!r}; labels={labels}')
        return found[0]
    def get(self,cls,member,ref):
        path,labels=self.worker('property',cls,member)
        output=self.match(member,labels)
        return self.run(path,{'reference':ref},[output,'error out'])[output]
    def set(self,cls,member,ref,value):
        path,labels=self.worker('property',cls,member,True)
        self.run(path,{'reference':ref,self.match(member,labels):value},['error out'])
    def invoke(self,cls,member,ref,**inputs):
        path,labels=self.worker('method',cls,member)
        if (cls,member)==('GObject','Replace'):
            path,labels=self.variant(path,labels,{'Style','Path','Palette String'}-set(inputs))
        actual={'reference':ref,**{self.match(k,labels):v for k,v in inputs.items()}}
        outputs=[s for s in labels if s not in actual and s not in ['reference out','error in (no error)']]
        result=self.run(path,actual,outputs)
        result.pop('error out',None)
        return result
    def variant(self,source,labels,unwire):
        key=('variant',str(source),tuple(sorted(unwire)))
        if key in self.workers:return self.workers[key]
        path=self.work/f'v-{uuid.uuid4().hex[:8]}.vi';shutil.copy2(source,path)
        node=self.find(path,'Invoke')[0]
        for terminal in self.get('Node','Terminals[]',node):
            name=self.get('Terminal','Name',terminal)
            if name in unwire:
                wire=self.get('Terminal','Connected Wire',terminal)
                if wire:self.invoke('Generic','Delete',wire)
        v=self.vi(str(path));v._FlagAsMethod('SaveInstrument');v.SaveInstrument(str(path),False,False)
        self.workers[key]=(path,labels)
        return path,labels
    def add(self,path,diagram=None):
        diagram=diagram if diagram is not None else self.find(path,'TopLevelDiagram')[0]
        old={self.uid(n) for n in self.find(path,'Function')}
        result=self.call(self.vendor/'Create Add.vi',{
            'Diagram in':diagram,'location (0, 0)':(100,200),'x':0,'y':0,
            'error in (no error)':(False,0,''),'Diagram out':0,'x+y':0,'error out':(False,0,'')})
        return next(n for n in self.find(path,'Function') if self.uid(n) not in old)
    def uid(self,ref):return int(self.get('GObject','UID',ref))
    def new_object(self,owner,style,position=(100,100),bounds=(200,100),cls='GObject'):
        styles=json.loads((ROOT/'engine/style-catalog.json').read_text())
        if style not in styles:raise ValueError('Unknown installed style')
        code=styles[style];tag=hashlib.sha256((cls+':'+str(code)).encode()).hexdigest()[:12]
        path=self.work/f'object-{tag}.vi'
        if not path.exists() or 'Created Object' not in self.labels(path):
            if path.exists():
                v=self.vi(str(path));v._FlagAsMethod('Revert');v.Revert()
            else:self.blank(path)
            node=self.invoke('GObject','Replace',self.add(path),**{'Palette String':'New VI Object'})['Replace']
            self.call(self.runtime/'QuickDropSupport/Wire All Terminals_core.vi',{'SelList[]':[node],'Create constants?':False,'User string':'',
                'error in (no error)':(False,0,''),'changes made?':False,'error out':(False,0,'')})
            terms={self.get('Terminal','Name',t):t for t in self.get('Node','Terminals[]',node)}
            self.invoke('Generic','Delete',self.get('Terminal','Connected Wire',terms['vi object class']))
            constant=self.invoke('Terminal','Create Constant',terms['vi object class'])['Create Constant']
            types=self.get('ClassSpecifierConstant','All Types[]',constant)
            row=next(row for row in types if row[2]==cls)
            self.invoke('ClassSpecifierConstant','Set Type',constant,**{'ID String':row[0]})
            if cls not in ['GObject','ForLoop','WhileLoop','CaseStructure','EventStructure']:raise PermissionError('Only public creation classes are permitted')
            for key,newlabel in [('owner refnum','Owner')]:
                self.invoke('Generic','Delete',self.get('Terminal','Connected Wire',terms[key]))
                control=self.invoke('Terminal','Create Control',terms[key])['Create Control']
                self.set('Text','Text',self.get('Control','Label',control),newlabel)
            self.invoke('Generic','Delete',self.get('Terminal','Connected Wire',terms['object refnum']))
            control=self.invoke('Terminal','Create Indicator',terms['object refnum'])['Create Indicator']
            self.set('Text','Text',self.get('Control','Label',control),'Created Object')
            self.invoke('Generic','Delete',self.get('Terminal','Connected Wire',terms['style']))
            temporary=self.add(path)
            t=next(t for t in self.get('Node','Terminals[]',temporary) if self.get('Terminal','Name',t)=='x')
            c=self.invoke('Terminal','Create Constant',t,Value=code)['Create Constant']
            self.invoke('Generic','Delete',temporary)
            self.invoke('Terminal','Connect Wire',terms['style'],**{'Wire Source':self.get('Constant','Terminal',c),
                'Auto Wire? (T)':False,'Auto Route? (F)':False,'Wiring Specs':''})
            self.invoke('Generic','Delete',self.get('Terminal','Connected Wire',terms['path']))
            v=self.vi(str(path));v._FlagAsMethod('SaveInstrument');v.SaveInstrument(str(path),False,False)
        return self.run(path,{'Owner':owner,'location':tuple(position),'bounds':tuple(bounds)},['Created Object','error out'])['Created Object']
    def type_xml(self,terminal):
        factory=self.runtime/json.loads((self.runtime/'manifest.json').read_text())['type_xml_worker'] if (self.runtime/'manifest.json').exists() else Path(json.loads((ROOT/'phase2/reports/type-xml.json').read_text())['worker'])
        result=self.run(factory,{'reference':terminal},['Type XML','error out'])['Type XML']
        import xml.etree.ElementTree as ET
        root=ET.fromstring(result)
        datatype=next((c.tag for c in root if c.tag!='Name'),root.tag)
        return {'labview_type':datatype,'xml':result,'source':'Terminal.Data Type -> Flatten To XML inside G'}
    def new_from_scratch(self,path):
        path=Path(path)
        if not path.is_absolute() or path.suffix.lower()!='.vi':raise ValueError('Absolute .vi path required')
        path=path.parent.resolve(strict=True)/path.name
        if not path.parent.is_relative_to((ROOT/'test-vis').resolve()):raise PermissionError('Outside test-vis')
        if path.exists() or path.is_symlink():raise FileExistsError(path)
        factory=self.runtime/json.loads((self.runtime/'manifest.json').read_text())['new_vi_worker'] if (self.runtime/'manifest.json').exists() else Path(json.loads((ROOT/'phase2/reports/next-probes.json').read_text())['new_vi_worker'])
        outcome=self.run(factory,{'Path to Saved File':str(path)},['Save Error'])
        if outcome['Save Error'][0]:raise RuntimeError(str(outcome['Save Error']))
        if not path.exists():raise RuntimeError('New VI factory did not save a file')
        return self.vi(str(path))
    def graph(self,path):
        refs={}
        result={'vi':str(path),'source':'live public VI Scripting','nodes':[],
            'controls':[],'terminals':{},'wires':[],'id_scope':'LabVIEW UID within this VI; may be reused after deletion'}
        def terminal(t):
            ident=str(self.uid(t))
            refs[ident]=t
            if ident not in result['terminals']:
                kind=self.get('Generic','Class Name',t)
                item={'id':ident,'class':kind,'name':self.get('Terminal','Name',t),
                    'is_source':self.get('Terminal','Is Source?',t),
                    'owner_id':str(self.uid(self.get('Generic','Owner',t)))}
                try:item['data_type_exemplar']=self.get('Terminal','Data Type',t)
                except Exception as exc:item['data_type_exemplar_error']=str(exc)
                try:item['data_type']=self.type_xml(t)
                except Exception as exc:item['data_type_error']=str(exc)
                if kind=='ControlTerminal':
                    control=self.get('ControlTerminal','Control',t)
                    item['control_id']=str(self.uid(control))
                result['terminals'][ident]=item
            return ident
        for n in self.find(path,'Node'):
            refs[str(self.uid(n))]=n
            result['nodes'].append({'id':str(self.uid(n)),'class':self.get('Generic','Class Name',n),
                'style':self.get('Node','Style',n),'position':self.get('GObject','Position',n),
                'owner_id':str(self.uid(self.get('Generic','Owner',n))),
                'terminal_ids':[terminal(t) for t in self.get('Node','Terminals[]',n)]})
            if result['nodes'][-1]['class']=='SubVI':
                try:result['nodes'][-1]['subvi_path']=self.get('SubVI','VI Path',n)
                except Exception as exc:result['nodes'][-1]['subvi_path_error']=str(exc)
        result['diagrams']=[]
        for diagram in self.find(path,'Diagram'):
            refs[str(self.uid(diagram))]=diagram
            kind=self.get('Generic','Class Name',diagram)
            info={'id':str(self.uid(diagram)),'class':kind}
            if kind!='TopLevelDiagram':info['owner_id']=str(self.uid(self.get('Generic','Owner',diagram)))
            result['diagrams'].append(info)
        for c in self.find(path,'Control',0):
            refs[str(self.uid(c))]=c
            info={'id':str(self.uid(c)),'class':self.get('Generic','Class Name',c),
                'label':self.get('Text','Text',self.get('Control','Label',c)),
                'is_indicator':self.get('Control','Indicator',c),
                'position':self.get('GObject','Position',c)}
            try:info['terminal_id']=terminal(self.get('Control','Terminal',c))
            except Exception as exc:info['terminal_id']=None;info['terminal_error']=str(exc)
            result['controls'].append(info)
        for w in self.find(path,'Wire'):
            refs[str(self.uid(w))]=w
            endpoints=[terminal(t) for t in self.get('Wire','Terminals[]',w)]
            result['wires'].append({'id':str(self.uid(w)),'terminal_ids':endpoints,
                'source_ids':[t for t in endpoints if result['terminals'][t]['is_source']],
                'sink_ids':[t for t in endpoints if not result['terminals'][t]['is_source']]})
        for t in self.find(path,'Terminal'):terminal(t)
        result['constants']=[]
        for c in self.find(path,'Constant'):
            refs[str(self.uid(c))]=c
            kind=self.get('Generic','Class Name',c)
            info={'id':str(self.uid(c)),'class':kind,'owner_id':str(self.uid(self.get('Generic','Owner',c))),
                'position':self.get('GObject','Position',c)}
            try:info['value']=self.get(kind,'Value',c)
            except Exception as exc:info['value_error']=str(exc)
            try:info['terminal_id']=terminal(self.get('Constant','Terminal',c))
            except Exception as exc:info['terminal_error']=str(exc)
            result['constants'].append(info)
        result['tunnels']=[]
        for t in self.find(path,'Tunnel'):
            refs[str(self.uid(t))]=t
            kind=self.get('Generic','Class Name',t)
            info={'id':str(self.uid(t)),'class':kind,'owner_id':str(self.uid(self.get('Generic','Owner',t))),
                'outside_terminal_id':terminal(self.get('Tunnel','Outside Terminal',t)),
                'inside_terminal_ids':[terminal(x) for x in self.get('Tunnel','Inside Terminals[]',t)]}
            if kind=='RightShiftRegister':info['left_register_ids']=[str(self.uid(x)) for x in self.get('RightShiftRegister','Left Registers[]',t)]
            result['tunnels'].append(info)
        for n in result['nodes']:
            if n['class']=='CaseStructure':n['case_names']=self.get('CaseStructure','Frame Names',refs[n['id']])
        self.last_graph_refs=refs
        result['structures']=[n for n in result['nodes'] if n['class'] in
            ['ForLoop','WhileLoop','CaseStructure','Case','EventStructure','FlatSequence','StackedSequence']]
        return result
    def release(self):
        for path,v in list(self.references.items()):
            if any(str(p) in path for p in [self.runtime,self.work,self.vendor,ROOT/'test-vis/traverseref.llb',ROOT/'test-vis/QuickDropSupport']):
                try:v._FlagAsMethod('ReinitializeAllToDefault');v.ReinitializeAllToDefault()
                except Exception:pass
        self.close()

def main():
    e=PublicEngine();report={}
    try:
        target=ROOT/'test-vis/ni-scripting-phase2/Creating VIs/Test - SubVI Add.vi'
        nodes=e.find(target,'Node')
        report['nodes']=[]
        for n in nodes:
            item={'ref':n}
            for cls,prop in [('Generic','Class Name'),('Node','Style'),('Node','Terminals[]'),('GObject','Owner')]:
                try:item[prop]=e.get(cls,prop,n)
                except Exception as exc:item[prop]={'error':str(exc)}
            report['nodes'].append(item)
        for cls,member in [('Generic','Delete'),('GObject','Replace'),('Terminal','Connect Wire'),('Terminal','Create Control'),('Terminal','Create Indicator')]:
            try:
                p,labels=e.worker('method',cls,member)
                report[f'{cls}.{member}']={'path':str(p),'labels':labels}
            except Exception as exc:report[f'{cls}.{member}']={'error':str(exc)}
    except Exception as exc:
        import traceback
        report['error']=str(exc);report['traceback']=traceback.format_exc()
    finally:
        (ROOT/'phase2/reports/public-engine.json').write_text(json.dumps(report,indent=2,default=str))
        e.close()
    print(json.dumps(report,indent=2,default=str))
if __name__=='__main__':main()
