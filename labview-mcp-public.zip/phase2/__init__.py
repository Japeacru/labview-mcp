"""Programmatic bootstrap and acceptance evidence for the public G engine."""
