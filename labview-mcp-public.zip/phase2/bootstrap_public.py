"""Bootstrap public Scripting via NI Traverse + MIT LV-Scripting. No private APIs."""
import sys,os,json,shutil,uuid,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
os.environ['LABVIEW_ALLOW_AUTOMATION_INSTANCE']='1'
import pythoncom
from win32com.client import VARIANT
from backend import Backend,error
from export_parser import ExportParser

class PublicBootstrap(Backend):
    def __init__(self):
        super().__init__()
        self.vendor=ROOT/'test-vis/vendor/lv-scripting-f7a14bd02f2c7c1fb062201657568a2ea6e0b7f6/source/library'
        self.work=ROOT/'test-vis/engine';self.work.mkdir(exist_ok=True)
        self.runtime=ROOT/'engine/runtime'
        if (self.runtime/'manifest.json').exists():
            self.vendor=self.runtime/'vendor/lv-scripting-f7a14bd02f2c7c1fb062201657568a2ea6e0b7f6/source/library'
            self.work=self.runtime/'workers';self.work.mkdir(exist_ok=True)
    def vi(self,path):
        safe=Path(path).resolve(strict=True)
        if safe.is_relative_to(self.runtime.resolve()) and safe.suffix.lower()=='.vi':
            key=str(safe)
            if key not in self.references:self.references[key]=self.connect().GetVIReference(key,'',False,0)
            return self.references[key]
        return super().vi(path)
    def call(self,path,params):
        self.trace('call',str(path),list(params))
        v=self.vi(str(path))
        names,values=v._oleobj_.InvokeTypes(v._oleobj_.GetIDsOfNames('Call'),0,pythoncom.DISPATCH_METHOD,
            (pythoncom.VT_VOID,0),((pythoncom.VT_BYREF|pythoncom.VT_VARIANT,3),(pythoncom.VT_BYREF|pythoncom.VT_VARIANT,3)),list(params),list(params.values()))
        result=dict(zip(names,values))
        err=result.get('error out')
        if isinstance(err,(tuple,list)) and err[0]:raise RuntimeError(f'{path.name}: {err}')
        return result
    def find(self,path,cls,target=1):
        path=Path(path)
        base=self.runtime if (self.runtime/'manifest.json').exists() else ROOT/'test-vis'
        result=self.call(base/'traverseref.llb/Traverse for GObjects.vi',
            {'VI Refnum':self.vi(str(path)),'Class Name':cls,'Traverse Target':target,
             'Traverse Generated Code (F)':False,'error in (no error)':(False,0,''),
             'References':[],'# of Refs':0,'error out':(False,0,''),'dup VI Refnum':0})
        # Reacquire before releasing the old COM reference, keeping the VI loaded.
        self.references[str(path.resolve())]=self.connect().GetVIReference(str(path.resolve()),'',False,0)
        return list(result['References'])
    def blank(self,path):
        if path.exists():raise FileExistsError(path)
        source=ROOT/'test-vis/ni-scripting-phase2/Creating Objects/Test - Create from Ref Target.vi'
        if (self.runtime/'manifest.json').exists():source=self.runtime/'bootstrap-empty.vi'
        shutil.copy2(source,path)
        return self.vi(str(path))
    def labels(self,path):
        text,_=self.export(str(path));p=ExportParser();p.feed(text)
        return [x['name'] for x in p.controls if x['parent_index'] is None and x['name']]
    def run(self,path,inputs,outputs):
        self.trace('run',str(path),list(inputs)+outputs)
        v=self.vi(str(path));v._FlagAsMethod('SetControlValue','GetControlValue','Run','ReinitializeAllToDefault')
        v.ReinitializeAllToDefault()
        for name,value in inputs.items():v.SetControlValue(name,value)
        v.Run(True);deadline=time.monotonic()+8
        while v.ExecState==2:
            if time.monotonic()>deadline:
                v._FlagAsMethod('Abort');v.Abort();raise TimeoutError(f'Generated helper timeout: {path}')
            time.sleep(.01)
        result={name:v.GetControlValue(name) for name in outputs}
        err=result.get('error out')
        if isinstance(err,(tuple,list)) and err[0]:raise RuntimeError(f'{path.name}: {err}')
        return result
    def trace(self,operation,path,detail):
        if (ROOT/'logs/inflight.json').exists():
            (ROOT/'logs/active-helper.json').write_text(json.dumps({'path':str(Path(path).resolve()),'operation':operation,'pid':os.getpid()}))
        with (ROOT/'phase2/reports/engine-trace.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps({'time':time.time(),'op':operation,'path':path,'detail':detail},default=str)+'\n')
    def property_worker(self,cls,member):
        path=self.work/f'p-{uuid.uuid4().hex[:8]}.vi'
        self.blank(path)
        diagram=self.find(path,'TopLevelDiagram')[0]
        row=VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_VARIANT,(member,False))
        props=VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_VARIANT,(row,))
        created=self.call(self.vendor/'Create Property Node.vi',{
            'Diagram in':diagram,'Class Name':'VI Server:'+cls,'Properties':props,
            'location (0, 0)':(100,200),'reference':0,'error in':0,'Inputs':[],
            'error in (no error)':(False,0,''),'Diagram out':0,'Outputs':[],'error out':(False,0,'')})
        print('created',repr(created),flush=True)
        helper=self.vi(str(self.vendor/'Create Property Node.vi'));helper._FlagAsMethod('GetControlValue')
        print('helper-error-cluster',repr(helper.GetControlValue('error out')),flush=True)
        print('all',repr(self.find(path,'GObject')),flush=True)
        node=self.find(path,'Property')[0]
        wired=self.call(ROOT/'test-vis/QuickDropSupport/Wire All Terminals_core.vi',{
            'SelList[]':[node],'Create constants?':False,'User string':'',
            'error in (no error)':(False,0,''),'changes made?':False,'error out':(False,0,'')})
        v=self.vi(str(path));v._FlagAsMethod('SaveInstrument');v.SaveInstrument(str(path),False,False)
        return path,created,wired

def main():
    b=PublicBootstrap();report={}
    try:
        path,created,wired=b.property_worker('Node','Terminals[]')
        report.update(worker=str(path),created=created,wired=wired,labels=b.labels(path))
        target=ROOT/'test-vis/ni-scripting-phase2/Creating VIs/Test - SubVI Add.vi'
        nodes=b.find(target,'Node');report['target_nodes']=nodes
        report['calls']=[b.run(path,{'reference':n},['Terminals[]','error out']) for n in nodes]
    except Exception as e:
        import traceback
        report['error']=error(e);report['traceback']=traceback.format_exc()
    finally:
        (ROOT/'phase2/reports/bootstrap-public.json').write_text(json.dumps(report,indent=2,default=str))
        b.close()
    print(json.dumps(report,indent=2,default=str))
if __name__=='__main__':main()
