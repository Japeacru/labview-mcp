"""Transactional, bounded public Scripting operations. No arbitrary property dispatch."""
import json,re,shutil,uuid
from pathlib import Path
from policy import test_vi
from security import ROOT,digest
from win32com.client import VARIANT
import pythoncom

SCHEMAS={
 'add_node':({'id','type'},{'diagram','position'}),
 'create_structure':({'id','type'},{'diagram','position','selector','frames'}),
 'create_literal':({'id','value'},{'diagram','position'}),
 'add_shift_register':({'id','loop'},{'y'}),
 'create_tunnel':({'id','source','destination'},{'index_mode'}),
 'create_panel_object':({'id','style'},{'label','position','size','indicator','owner','diagram'}),
 'create_control':({'id','terminal'},{'label','indicator','style','position'}),
 'create_constant':({'id','terminal','value'},set()),
 'set_constant':({'id','value'},set()),
 'set_label':({'id','value'},set()),
 'set_indicator':({'id','value'},set()),
 'set_position':({'id','value'},set()),
 'set_size':({'id','value'},set()),
 'set_default':({'id','value'},set()),
 'set_enum_items':({'id','items'},set()),
 'set_case_frames':({'id','names'},set()),
 'move_object':({'id','diagram'},{'position'}),
 'set_numeric_range':({'id','minimum','maximum'},{'increment'}),
 'cleanup':(set(),{'recursive'}),
 'create_comment':({'id','text'},{'diagram','position'}),
 'create_decoration':({'id','style'},{'position','size'}),
 'connect':({'source','destination'},set()),
 'disconnect_wire':({'id'},set()),'delete_object':({'id'},set()),
 'insert_subvi':({'id','path'},{'diagram','position'}),
 'configure_connector':({'assignments'},{'pattern'}),
 'set_description':({'value'},set()),
}
STYLES={'Numeric':'Numeric','Boolean':'Push Button','LED':'Round LED',
        'String':'String','WaveformChart':'Waveform Chart','WaveformGraph':'Waveform Graph','XYGraph':'XY Graph'}

class AdvancedPatch:
 def __init__(self,engine):self.e=engine
 def run(self,vi_path,operations,dry_run=True,expected_hash=None,confirm_destructive=False):
    e=self.e;p=test_vi(vi_path);initial=digest(p)
    if expected_hash and expected_hash!=initial:raise ValueError('EXTERNAL_CHANGE: expected hash differs from disk')
    if not operations or len(operations)>256:raise ValueError('Expected 1..256 operations')
    v=e.vi(str(p));v._FlagAsMethod('GetLockState')
    if v.GetLockState(VARIANT(pythoncom.VT_BYREF|pythoncom.VT_BOOL,False))!=1:raise PermissionError('Protected VI')
    if v.ExecState not in (0,1) or v.FPWinOpen or v.Callers or v.VIModificationBitSet:
        raise ValueError('VI must be clean, stopped, uncalled and panel closed')
    before=e.graph(p);refs=dict(e.last_graph_refs);root=e.find(p,'TopLevelDiagram')[0]
    known=set(refs);aliases=set();deleted=set()
    labels={}
    for c in before['controls']:
        if c['label'] in labels:labels[c['label']]=None
        else:labels[c['label']]=c['terminal_id']
    def valid_ref(value):
        if not isinstance(value,str):raise ValueError('References must be strings')
        head=value.split('.',1)[0]
        if head in deleted:raise ValueError('Reference to deleted object')
        if value not in known and value not in labels and head not in aliases|known:raise ValueError('Unknown reference: '+value)
        if value in labels and labels[value] is None:raise ValueError('Ambiguous control label')
    destructive=False
    for op in operations:
        a=op.get('action');fields=set(op)-{'action'}
        if a not in SCHEMAS:raise ValueError('Unsupported action: '+str(a))
        required,optional=SCHEMAS[a]
        if not required<=fields or not fields<=required|optional:raise ValueError('Invalid fields for '+a)
        if a.startswith('create_') or a in ['add_node','add_shift_register','insert_subvi']:
            alias=op['id']
            if not isinstance(alias,str) or not re.fullmatch('[A-Za-z_][A-Za-z0-9_]{0,31}',alias) or alias in aliases|known|set(labels):raise ValueError('Invalid/duplicate alias')
            if a=='add_node':
                catalog=json.loads((ROOT/'engine/catalog-verified.json').read_text())
                if op['type'] not in catalog or not catalog[op['type']].get('creation_id'):raise ValueError('Node must have a verified creation ID in catalog')
            if a=='create_structure' and op['type'] not in ['For','While','CaseBoolean','Case','Event']:raise ValueError('Unsupported structure')
            if a=='create_panel_object' and op['style'] not in json.loads((ROOT/'engine/style-catalog.json').read_text()):raise ValueError('Unknown installed style')
            if a=='insert_subvi':test_vi(op['path'])
            for key in ['diagram','selector','loop','terminal','source','destination','owner']:
                if key in op and op[key]!='root':valid_ref(op[key])
            aliases.add(alias)
        elif a in ['connect']:
            valid_ref(op['source']);valid_ref(op['destination'])
        elif a=='configure_connector':
            destructive=True
            if not isinstance(op['assignments'],dict):raise ValueError('assignments must map terminal indices to control IDs')
            for index,value in op['assignments'].items():
                if not str(index).isdigit() or not 0<=int(index)<64:raise ValueError('Invalid connector index')
                valid_ref(value)
        elif a not in ['set_description','cleanup']:
            valid_ref(op['id'])
            if a in ['delete_object','disconnect_wire']:destructive=True;deleted.add(op['id'])
            if a=='disconnect_wire' and op['id'] not in {w['id'] for w in before['wires']}:raise ValueError('disconnect_wire requires a wire UID')
        if a=='create_structure' and op['type'].startswith('Case') and 'selector' not in op:raise ValueError('Case selector required')
        if a=='set_enum_items' and (not isinstance(op['items'],list) or not op['items'] or len(op['items'])>256 or any(not isinstance(x,str) for x in op['items'])):raise ValueError('Invalid enum items')
        if a=='set_numeric_range' and op['minimum']>op['maximum']:raise ValueError('Invalid numeric range')
        if 'position' in op:self.pair(op['position'])
        if a in ['set_position','set_size']:self.pair(op['value'],positive=a=='set_size')
        if a in ['set_label','set_description'] and (not isinstance(op['value'],str) or len(op['value'])>65536):raise ValueError('Invalid text')
        if 'style' in op and a=='create_control' and op['style'] not in STYLES:raise ValueError('Unsupported control style')
    if dry_run:return {'ok':True,'dry_run':True,'changed':False,'preview_hash':initial,
        'operations':operations,'requires_confirmation':destructive,'validation':'Schema, references and disk hash; final types checked by LabVIEW'}
    if destructive and not confirm_destructive:raise PermissionError('DESTRUCTIVE_CONFIRMATION_REQUIRED: inspect preview and pass confirm_destructive=true')
    if expected_hash is None:raise ValueError('PREVIEW_REQUIRED: pass expected_hash from dry-run preview_hash')
    if digest(p)!=initial:raise ValueError('EXTERNAL_CHANGE during preview')
    folder=ROOT/'backups'/('advanced-'+uuid.uuid4().hex);folder.mkdir(parents=True)
    backup=folder/p.name;shutil.copy2(p,backup);applied=[];created={};created_actions={};ends={}
    def obj(token):
        if token in created:return created[token]
        if token in refs:return refs[token]
        if token in labels and labels[token]:return refs[labels[token]]
        if token in ends:return ends[token]
        head,sep,tail=token.partition('.')
        if not sep or head not in created and head not in refs:raise ValueError('Cannot resolve '+token)
        n=created[head] if head in created else refs[head];kind=e.get('Generic','Class Name',n)
        if tail=='diagram':return e.get('Loop','Diagram',n)
        if tail.startswith('case:'):
            return e.get('Structure','Diagrams[]',n)[int(tail[5:])]
        if tail=='stop':return e.get('WhileLoop','Loop End Ref',n)
        if tail=='index':return e.get('Loop','Loop Counter',n)
        if tail=='terminal' and created_actions.get(head) in ['create_control','create_panel_object']:return e.get('Control','Terminal',n)
        if tail=='terminal' and 'Constant' in kind:return e.get('Constant','Terminal',n)
        if tail in ['inside','outside','left_inside','left_outside']:
            if tail.startswith('left_'):n=e.get('RightShiftRegister','Left Registers[]',n)[0]
            return e.get('Tunnel','Inside Terminals[]',n)[0] if tail.endswith('inside') else e.get('Tunnel','Outside Terminal',n)
        if tail.startswith('inside:'):return e.get('Tunnel','Inside Terminals[]',n)[int(tail[7:])]
        candidates=e.get('Node','Terminals[]',n) if kind not in ['Digital','Boolean','String','WaveformChart','WaveformGraph','XYGraph'] else [e.get('Control','Terminal',n)]
        if tail.startswith('term:'):return candidates[int(tail[5:])]
        if tail=='terminal' and len(candidates)==1:return candidates[0]
        found=[t for t in candidates if e.get('Terminal','Name',t)==tail]
        if len(found)!=1:raise ValueError('Unknown/ambiguous terminal '+token)
        return found[0]
    def diagram(op):return root if op.get('diagram','root')=='root' else obj(op['diagram'])
    def wire(source,destination,auto=False):
        if not e.get('Terminal','Is Source?',source) or e.get('Terminal','Is Source?',destination):raise ValueError('Wrong wire direction')
        return e.invoke('Terminal','Connect Wire',destination,**{'Wire Source':source,'Auto Wire? (T)':auto,'Auto Route? (F)':False,'Wiring Specs':''})
    try:
        for op in operations:
            a=op['action'];n=None
            if a=='add_node':
                n=e.add(p,diagram(op))
                if op['type']!='Add':n=e.invoke('GObject','Replace',n,**{'Palette String':op['type']})['Replace']
            elif a=='create_structure':
                kind=op['type'];cls={'For':'ForLoop','While':'WhileLoop','CaseBoolean':'CaseStructure','Case':'CaseStructure','Event':'EventStructure'}[kind]
                if kind=='Event':
                    n=e.new_object(diagram(op),'Event Structure',op.get('position',[100,100]));created[op['id']]=n;created_actions[op['id']]=a;applied.append(op);continue
                old=set(e.find(p,cls))
                params={'Diagram in':diagram(op),'location (0, 0)':tuple(op.get('position',[100,100])),
                    'Inputs':[],'error in (no error)':(False,0,''),'error out':(False,0,'')}
                if kind in ['CaseBoolean','Case']:
                    params.update({'Selector':obj(op['selector']),'Selected Diagram':0})
                    source='Create Case Structure (Boolean).vi' if kind=='CaseBoolean' else 'Create Case Structure.vi'
                    if kind=='Case':params['Frames']=op.get('frames',[])
                else:
                    params.update({'Shift Register Inputs':[],'Inputs Indexing?':[],'Diagram out':0,'Shift Registers':[],'Loop Counter':0})
                    source=f'Create {kind} Loop.vi'
                e.call(e.vendor/source,params)
                n=next(x for x in e.find(p,cls) if x not in old)
            elif a=='add_shift_register':n=e.invoke('Loop','Add Shift Register',obj(op['loop']),**{'Y Positon':op.get('y',60)})['Add Shift Register']
            elif a=='create_tunnel':
                old={e.uid(t) for t in e.find(p,'Tunnel')}
                wire(obj(op['source']),obj(op['destination']),True)
                new=[t for t in e.find(p,'Tunnel') if e.uid(t) not in old]
                if len(new)!=1:
                    (folder/'failed-graph.json').write_text(json.dumps(e.graph(p),indent=2,default=str))
                    raise ValueError(f'Expected exactly one new tunnel, got {len(new)} for {op["id"]}; diagnostic {folder}')
                n=new[0]
                if 'index_mode' in op:e.set('LoopTunnel','Index Mode',n,op['index_mode'])
            elif a=='create_panel_object':
                owner=obj(op['owner']) if 'owner' in op else e.get('VI','Front Panel',e.vi(str(p)))
                n=e.new_object(owner,op['style'],op.get('position',[100,100]),op.get('size',[200,100]))
                if 'label' in op:e.set('Text','Text',e.get('Control','Label',n),op['label'])
                if 'indicator' in op:e.set('Control','Indicator',n,op['indicator'])
                if 'owner' not in op:
                    terminal=e.get('Control','Terminal',n)
                    e.invoke('GObject','Move',terminal,Owner=diagram(op))
            elif a=='insert_subvi':
                old=set(e.find(p,'SubVI'))
                e.call(e.vendor/'Create SubVI.vi',{'Diagram in':diagram(op),'location (0, 0)':tuple(op.get('position',[100,100])),
                    'VI Reference':e.vi(op['path']),'Input Names':[],'Inputs':[],'Output Names':[],'Outputs':[],
                    'Diagram out':0,'error in (no error)':(False,0,''),'error out':(False,0,'')})
                n=next(x for x in e.find(p,'SubVI') if x not in old)
            elif a=='create_control':
                t=obj(op['terminal']);method='Create Indicator' if op.get('indicator',e.get('Terminal','Is Source?',t)) else 'Create Control'
                n=e.invoke('Terminal',method,t)[method]
                if 'style' in op:n=e.invoke('GObject','Replace',n,**{'Palette String':STYLES[op['style']]})['Replace']
                if 'label' in op:e.set('Text','Text',e.get('Control','Label',n),op['label'])
            elif a=='create_constant':n=e.invoke('Terminal','Create Constant',obj(op['terminal']),Value=op['value'])['Create Constant']
            elif a=='create_literal':
                value=op['value']
                if not isinstance(value,(str,int,float)) or isinstance(value,bool):raise ValueError('Literal supports strings and numbers')
                n=e.new_object(diagram(op),'String Constant' if isinstance(value,str) else 'Numeric Constant',op.get('position',[100,100]))
                e.set(e.get('Generic','Class Name',n),'Value',n,value)
            elif a=='set_constant':
                n=obj(op['id']);e.set(e.get('Generic','Class Name',n),'Value',n,op['value']);n=None
            elif a=='set_label':e.set('Text','Text',e.get('Control','Label',obj(op['id'])),op['value'])
            elif a=='set_indicator':e.set('Control','Indicator',obj(op['id']),op['value'])
            elif a=='set_position':e.set('GObject','Position',obj(op['id']),tuple(op['value']))
            elif a=='set_size':
                target=obj(op['id']);kind=e.get('Generic','Class Name',target)
                if kind=='String':e.set('String','Size',target,tuple(op['value']))
                elif kind in ['WaveformGraph','WaveformChart','XYGraph']:e.set(kind,'Plot Area:Size',target,tuple(op['value']))
                else:raise ValueError('SIZE_NOT_SUPPORTED: use a verified class-specific resize property; generic GObject has no writable Size')
            elif a=='set_default':
                control=obj(op['id']);e.set('Control','Value',control,op['value']);e.invoke('Control','Make Current Value Default',control)
            elif a=='set_enum_items':e.set('Enum','Strings[]',obj(op['id']),op['items'])
            elif a=='set_case_frames':e.set('CaseStructure','Frame Names',obj(op['id']),op['names'])
            elif a=='move_object':
                e.invoke('GObject','Move',obj(op['id']),Owner=diagram(op))
                if 'position' in op:e.set('GObject','Position',obj(op['id']),tuple(op['position']))
            elif a=='set_numeric_range':
                for key,member in [('minimum','Minimum'),('maximum','Maximum'),('increment','Increment')]:
                    if key in op:e.set('Numeric','Data Entry Limits:'+member,obj(op['id']),op[key])
            elif a=='create_comment':
                n=e.new_object(diagram(op),'Free Label',op.get('position',[100,100]));e.set('Text','Text',n,op['text'])
            elif a=='create_decoration':
                owner=e.get('VI','Front Panel',e.vi(str(p)))
                n=e.new_object(owner,op['style'],op.get('position',[100,100]),op.get('size',[200,100]))
            elif a=='cleanup':
                ds=before['diagrams'] if op.get('recursive',True) else [d for d in before['diagrams'] if d['class']=='TopLevelDiagram']
                for d in reversed(ds):
                    if any(x.get('owner_id')==d['id'] for x in before['nodes']+before['constants']):e.invoke('Diagram','Clean Up Diagram',refs[d['id']])
            elif a=='connect':wire(obj(op['source']),obj(op['destination']))
            elif a in ['delete_object','disconnect_wire']:e.invoke('Generic','Delete',obj(op['id']))
            elif a=='configure_connector':
                con=e.get('VI','Connector Pane:Reference',e.vi(str(p)))
                if 'pattern' in op:e.set('ConnectorPane','Pattern',con,op['pattern'])
                for index,token in op['assignments'].items():e.invoke('ConnectorPane','Assign Control To Terminal',con,Control=obj(token),**{'Terminal Index':int(index)})
            elif a=='set_description':e.vi(str(p)).Description=op['value']
            if n is not None:
                created[op['id']]=n
                created_actions[op['id']]=a
                if 'position' in op:e.set('GObject','Position',n,tuple(op['position']))
            applied.append(op)
        after=e.graph(p);v=e.vi(str(p))
        if all(op['action'] in ['cleanup','set_position','set_size','create_comment','create_decoration'] for op in operations):
            def logic(g):
                return {'nodes':[{k:v for k,v in n.items() if k not in ['position']} for n in g['nodes']],
                    'constants':[{k:v for k,v in n.items() if k!='position'} for n in g['constants']],
                    'connections':sorted((tuple(sorted(w['source_ids'])),tuple(sorted(w['sink_ids']))) for w in g['wires'])}
            if logic(before)!=logic(after):raise RuntimeError('LAYOUT_CHANGED_LOGIC: reverting')
        if v.ExecState!=1:
            (folder/'failed-graph.json').write_text(json.dumps(after,indent=2,default=str))
            raise RuntimeError('FINAL_VI_NOT_EXECUTABLE: reverted without saving; diagnostic '+str(folder))
        if digest(p)!=initial:raise RuntimeError('EXTERNAL_CHANGE: disk changed during editing; not overwriting')
        alias_ids={k:str(e.uid(value)) for k,value in created.items() if k not in deleted}
        v._FlagAsMethod('SaveInstrument');v.SaveInstrument(str(p),False,False)
        from backend import acknowledge_save
        acknowledge_save(p)
    except Exception as exc:
        # Never overwrite an external writer; original bytes remain in the backup.
        restored=False;restore_error=None
        try:
            v=e.references.get(str(p))
            if v is None:v=e.connect().GetVIReference(str(p),'',False,0)
            v._FlagAsMethod('Revert');v.Revert();restored=True
            from backend import acknowledge_save
            acknowledge_save(p)
        except Exception as recovery:restore_error=str(recovery)
        (folder/'failure.json').write_text(json.dumps({'path':str(p),'failed_operation':op,'applied':applied,
            'error':str(exc),'disk_unchanged':digest(p)==initial,'reverted':restored,'restore_error':restore_error},indent=2,default=str))
        raise
    diff=self.diff(before,after)
    return {'ok':True,'dry_run':False,'backup':str(backup),'sha256':digest(p),'execution_state':1,
        'applied':applied,'aliases':alias_ids,
        'before':before,'after':after,'diff':diff,'execution_certificate_invalidated':True}
 @staticmethod
 def pair(value,positive=False):
    if not isinstance(value,(tuple,list)) or len(value)!=2 or any(not isinstance(x,int) or isinstance(x,bool) or abs(x)>100000 for x in value):raise ValueError('Expected bounded integer pair')
    if positive and min(value)<=0:raise ValueError('Size must be positive')
 @staticmethod
 def diff(before,after):
    result={}
    for key in ['nodes','controls','constants','wires','diagrams','tunnels']:
        b={x['id']:x for x in before.get(key,[])};a={x['id']:x for x in after.get(key,[])}
        result[key]={'added':[a[k] for k in a.keys()-b.keys()], 'removed':[b[k] for k in b.keys()-a.keys()],
            'modified':[{'before':b[k],'after':a[k]} for k in a.keys()&b.keys() if a[k]!=b[k]]}
    return result
