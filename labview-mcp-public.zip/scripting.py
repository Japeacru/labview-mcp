"""Bounded public VI Scripting operations for the existing MCP, on test copies only."""
import json,re,shutil,uuid
from pathlib import Path
from phase2.public_engine import PublicEngine
from policy import test_vi
from security import ROOT,digest

PALETTES={'Add':{'x':False,'y':False,'x+y':True},'Multiply':{'x':False,'y':False,'x*y':True}}

class ScriptingEngine(PublicEngine):
    def __init__(self):
        super().__init__();self.watch_external_changes=True
    def inspect(self,vi_path:str):
        path=test_vi(vi_path)
        graph=self.graph(path)
        graph.update(ok=True,complete=False,topology_available=True,
            limitations=['Topology is read from live VI Scripting, not string exports.',
                'Terminal types include native XML; every structure-specific field is not yet covered.'])
        unresolved=[]
        for section in ['nodes','controls','terminals','constants','tunnels']:
            rows=graph.get(section,[]);rows=rows.values() if isinstance(rows,dict) else rows
            for item in rows:
                for key,value in item.items():
                    if key.endswith('_error'):unresolved.append({'section':section,'id':item['id'],'field':key,'reason':value})
                if section=='nodes' and item['class'] not in ['Function','ForLoop','WhileLoop','CaseStructure','SubVI']:
                    unresolved.append({'section':section,'id':item['id'],'class':item['class'],'reason':'Topology read; class semantics not decoded'})
        graph['coverage']={'topology':True,'terminal_types':sum('data_type' in t for t in graph['terminals'].values()),
            'terminal_count':len(graph['terminals']),'unresolved':unresolved,
            'unverified_semantics':['events','feedback','locals/globals','typedef identity','queue/notifier reference targets','property/invoke member metadata']}
        graph['dependencies_between_objects']=[{'wire_id':w['id'],'source_terminal':s,'destination_terminal':d,
            'source_owner':graph['terminals'][s]['owner_id'],'destination_owner':graph['terminals'][d]['owner_id']}
            for w in graph['wires'] for s in w['source_ids'] for d in w['sink_ids']]
        return graph

    def patch(self,vi_path:str,operations:list[dict],dry_run:bool=True,expected_hash=None,confirm_destructive=False):
        from advanced_patch import AdvancedPatch
        return AdvancedPatch(self).run(vi_path,operations,dry_run,expected_hash,confirm_destructive)
