from contextlib import asynccontextmanager
from typing import Any
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from client import WorkerClient
worker=WorkerClient(timeout=45)

@asynccontextmanager
async def lifespan(server):
    try: yield {}
    finally: await worker.close()

mcp=FastMCP('labview',lifespan=lifespan,instructions='LabVIEW 2021 SP1, test-vis copies only. Live VI Scripting reads nodes, terminal endpoints, wires and UIDs. Graph patches support verified Add/Multiply scalar arithmetic; other palettes and complete type/structure semantics remain limited. No hardware execution. Consult labview_get_capabilities.')
READ=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False)
WRITE=ToolAnnotations(readOnlyHint=False,destructiveHint=True,openWorldHint=False)

@mcp.tool(annotations=READ)
async def labview_get_environment()->dict[str,Any]:
    """Read recorded environment inventory; connection status is a separate live query."""
    return await worker.request('environment')

@mcp.tool(annotations=READ)
async def labview_get_status()->dict[str,Any]:
    """Connect through explicit 32-bit COM activation; may start a separate LabVIEW instance."""
    return await worker.request('status')

@mcp.tool(annotations=READ)
async def labview_get_capabilities()->dict[str,Any]:
    """Report verified operations and explicit limitations."""
    return await worker.request('capabilities')

@mcp.tool(annotations=READ)
async def labview_list_vis()->dict[str,Any]:
    """Enumerate the connected instance; ExportedVIs fallback is incomplete."""
    return await worker.request('list_vis')

@mcp.tool(annotations=READ)
async def labview_inspect_vi(vi_path:str)->dict[str,Any]:
    """Read metadata of a .vi copy inside test-vis without execution."""
    return await worker.request('inspect_vi',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_block_diagram(vi_path:str)->dict[str,Any]:
    """Read live Scripting nodes, terminal endpoints, wires, UIDs and positions. See completeness limits."""
    return await worker.request('inspect_ir',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_controls(vi_path:str)->dict[str,Any]:
    """Read exported front panel records; direction and data types are unknown."""
    return await worker.request('list_controls',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_dependencies(vi_path:str)->dict[str,Any]:
    """Read VI dependency names and paths with diagram loading disabled."""
    return await worker.request('get_vi_dependencies',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_subvis(vi_path:str)->dict[str,Any]:
    """Read static direct callees; dynamic targets may be absent."""
    return await worker.request('list_subvis',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_execution_state(vi_path:str)->dict[str,Any]:
    """Read execution state; this is not a compiler error report."""
    return await worker.request('execution_state',vi_path=vi_path)

@mcp.tool(annotations=READ)
async def labview_get_control_value(vi_path:str,name:str)->dict[str,Any]:
    """Read an explicitly named front panel value."""
    return await worker.request('control_value',vi_path=vi_path,name=name)

@mcp.tool(annotations=WRITE)
async def labview_close_vi(vi_path:str)->dict[str,Any]:
    """Release only this server's reference; does not force-close user panels."""
    return await worker.request('close_vi',vi_path=vi_path)

@mcp.tool(annotations=WRITE)
async def labview_create_vi(output_path:str,operation:str)->dict[str,Any]:
    """Create an array add/multiply VI from a certified NI template; no arbitrary graph creation."""
    return await worker.request('create_vi',output_path=output_path,operation=operation)

@mcp.tool(annotations=WRITE)
async def labview_apply_patch(vi_path:str,operations:list[dict[str,Any]],dry_run:bool=True,expected_hash:str|None=None,confirm_destructive:bool=False)->dict[str,Any]:
    """Validate metadata or scalar arithmetic graph edits; dry-run by default, backup and restore on failure."""
    return await worker.request('apply_patch',vi_path=vi_path,operations=operations,dry_run=dry_run,expected_hash=expected_hash,confirm_destructive=confirm_destructive)

@mcp.tool(annotations=WRITE)
async def labview_run_test(vi_path:str,values:list[float],expected:float,timeout:float=5)->dict[str,Any]:
    """Run only SHA256-certified arithmetic test VIs. Timeout uses Abort, not orderly stop."""
    return await worker.request('run_test',vi_path=vi_path,values=values,expected=expected,timeout=timeout)

@mcp.tool(annotations=READ)
async def labview_search_nodes(query:str='',category_filter:str|None=None,offset:int=0,limit:int=25)->dict[str,Any]:
    """Search installed creator helpers and runtime-verified definitions; discovery is not execution verification."""
    return await worker.request('catalog',query=query,category_filter=category_filter,offset=offset,limit=limit)

@mcp.tool(annotations=READ)
async def labview_list_node_categories()->dict[str,Any]:
    return {'ok':True,'categories':(await worker.request('catalog'))['categories']}

@mcp.tool(annotations=READ)
async def labview_get_node_definition(name:str)->dict[str,Any]:
    return await worker.request('catalog',name=name)

@mcp.tool(annotations=READ)
async def labview_get_node_terminals(name:str)->dict[str,Any]:
    """Return recorded verified terminal definitions, or null when not yet probed."""
    result=await worker.request('catalog',name=name)
    return result

@mcp.tool(annotations=READ)
async def labview_inspect_section(vi_path:str,section:str='summary',offset:int=0,limit:int=50,diagram_id:str|None=None,class_filter:str|None=None,query:str|None=None)->dict[str,Any]:
    """Inspect compact paginated sections; full graph artifact and SHA256 cache are returned."""
    return await worker.request('inspect_section',vi_path=vi_path,section=section,offset=offset,limit=limit,diagram_id=diagram_id,class_filter=class_filter,query=query)

@mcp.tool(annotations=READ)
async def labview_analyze_impact(vi_path:str)->dict[str,Any]:
    """Read loaded callers before changing a subVI interface. Unloaded/dynamic callers remain unresolved."""
    return await worker.request('impact',vi_path=vi_path)

@mcp.tool(annotations=WRITE)
async def labview_run_fixture(vi_path:str,inputs:dict[str,Any],expected:dict[str,Any],timeout:float=5)->dict[str,Any]:
    """Run only administrator hash-certified functional fixtures and their certified dependency closure."""
    return await worker.request('run_fixture',vi_path=vi_path,inputs=inputs,expected=expected,timeout=timeout)

@mcp.tool(annotations=READ)
async def labview_analyze_project(project_path:str,offset:int=0,limit:int=50)->dict[str,Any]:
    """Read XML .lvproj inventory without execution. Implicit dependencies require incremental VI inspection."""
    return await worker.request('project_inventory',project_path=project_path,offset=offset,limit=limit)

@mcp.tool(annotations=READ)
async def labview_search_project(query:str,offset:int=0,limit:int=50)->dict[str,Any]:
    """Find explicit keywords/concepts in hash-current cached VI graphs; scope is incomplete."""
    return await worker.request('search_project',query=query,offset=offset,limit=limit)

@mcp.tool(annotations=READ)
async def labview_get_supported_datatypes()->dict[str,Any]:
    """Return native type descriptors actually read, without claiming every type shape is supported."""
    return await worker.request('supported_datatypes')

@mcp.tool(annotations=WRITE)
async def labview_recover_session(confirm_revert:bool=False)->dict[str,Any]:
    """Inspect an interrupted request and known helper. No LabVIEW restart or automatic Abort. Revert needs explicit confirmation."""
    return await worker.request('recover_session',confirm_revert=confirm_revert)

@mcp.tool(annotations=READ)
async def labview_export_image(vi_path:str,surface:str='diagram')->dict[str,Any]:
    """Export an image through native VI Server APIs. Never opens windows or captures the desktop."""
    return await worker.request('export_image',vi_path=vi_path,surface=surface)

if __name__=='__main__': mcp.run(transport='stdio')
