"""Cross-process serialization and explicit recovery after interrupted COM requests."""
import os,json,msvcrt
from contextlib import contextmanager
from security import ROOT
PURE={'environment','capabilities','catalog','supported_datatypes','project_inventory','search_project','recover_session'}
WRITE={'create_vi','apply_patch','close_vi'}
EXECUTE={'run_test','run_fixture'}
@contextmanager
def request_guard(request):
 folder=ROOT/'logs';folder.mkdir(exist_ok=True)
 with (folder/'com-session.lock').open('a+b') as lock:
    lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
    try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:raise RuntimeError('SESSION_BUSY: another MCP process owns the COM operation')
    marker=folder/'inflight.json';active=folder/'active-helper.json';owned=False
    try:
        method=request['operation'];role=os.environ.get('LABVIEW_MCP_ROLE','developer')
        if role not in ['reader','developer','executor']:raise PermissionError('Unknown MCP permission role')
        if method in WRITE and role!='developer':raise PermissionError('WRITE_PERMISSION_DENIED')
        if method in EXECUTE and role not in ['developer','executor']:raise PermissionError('EXECUTION_PERMISSION_DENIED')
        if marker.exists() and method not in PURE:raise RuntimeError('SESSION_QUARANTINED: previous request interrupted; inspect recover_session before continuing')
        if method not in PURE:
            marker.write_text(json.dumps({'pid':os.getpid(),'request':request},indent=2));owned=True
        yield
    finally:
        if owned:marker.unlink(missing_ok=True);active.unlink(missing_ok=True)
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)

def recover(adapter,confirm_revert=False):
 marker=ROOT/'logs/inflight.json';active=ROOT/'logs/active-helper.json'
 if not marker.exists():return {'ok':True,'quarantined':False,'changed':False}
 record=json.loads(marker.read_text());checks=[]
 if active.exists():
    helper=json.loads(active.read_text())
    v=adapter.engine().vi(helper['path']);state=v.ExecState;checks.append({'helper':helper['path'],'state':state})
    if state==2:return {'ok':False,'quarantined':True,'reason':'Helper still running; LabVIEW is not aborted or restarted','checks':checks}
 args=record['request'].get('arguments',{});target=args.get('vi_path') or args.get('output_path')
 if target and __import__('pathlib').Path(target).exists():
    from policy import test_vi
    from backend import OBSERVED_HASHES
    p=test_vi(target);OBSERVED_HASHES.pop(str(p),None);v=adapter.vi(str(p))
    checks.append({'vi':str(p),'state':v.ExecState,'dirty':bool(v.VIModificationBitSet)})
    if v.ExecState==2:return {'ok':False,'quarantined':True,'reason':'Target still running; no automatic Abort','checks':checks}
    if v.VIModificationBitSet:
        if not confirm_revert:return {'ok':False,'quarantined':True,'requires_confirmation':'confirm_revert restores the test copy from disk','checks':checks}
        v._FlagAsMethod('Revert');v.Revert()
 elif record['request']['operation'] in WRITE|EXECUTE:
    return {'ok':False,'quarantined':True,'reason':'Target cannot be inspected; manual diagnosis required','checks':checks}
 marker.unlink();active.unlink(missing_ok=True)
 return {'ok':True,'quarantined':False,'checks':checks,'labview_restarted':False}
