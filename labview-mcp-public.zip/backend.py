"""Local COM backend. No Run, Call, Abort, control writes or network API."""
import os
import struct
import tempfile
import time
import winreg
from pathlib import Path
import pythoncom
import pywintypes
from win32com.client import dynamic, VARIANT
from policy import test_vi
from export_parser import parse_export

CLSID = '{9A872070-0A06-11D1-90B7-00A024CE2744}'
EXPECTED_DIRECTORY = Path(r'C:\Program Files (x86)\National Instruments\LabVIEW 2021')
OBSERVED_HASHES = {}
def acknowledge_save(path):
    import hashlib
    safe=Path(path).resolve();OBSERVED_HASHES[str(safe)]=hashlib.sha256(safe.read_bytes()).hexdigest()

def error(exc):
    result = {'type': type(exc).__name__, 'message': str(exc)}
    if isinstance(exc, pywintypes.com_error):
        result['hresult'] = exc.hresult
        result['details'] = exc.excepinfo
    return result

class Backend:
    def __init__(self):
        pythoncom.CoInitialize()
        self.app = None
        self.references = {}
        self.connection_mode = None

    def connect(self):
        if self.app is not None:
            return self.app
        # Explicitly select the 32-bit registration; the 64-bit one is LV 2026 here.
        keyname = rf'CLSID\{CLSID}\LocalServer32'
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, keyname, 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_32KEY) as key:
            registered = winreg.QueryValue(key, None)
        expected = str(EXPECTED_DIRECTORY / 'LabVIEW.exe')
        if registered.strip().strip('"').casefold() not in {
            (expected + ' /Automation').casefold(), ('"' + expected + '" /Automation').casefold()
        }:
            raise RuntimeError(f'Unexpected 32-bit COM registration: {registered}')
        try:
            obj = pythoncom.GetActiveObject(CLSID).QueryInterface(pythoncom.IID_IDispatch)
            mode = 'running_object_table'
        except pywintypes.com_error:
            if os.environ.get('LABVIEW_ALLOW_AUTOMATION_INSTANCE') != '1':
                raise RuntimeError('No accessible running COM object. Explicit automation-instance opt-in is required.')
            for attempt in range(3):
                try:
                    obj = pythoncom.CoCreateInstance(CLSID, None,
                        pythoncom.CLSCTX_LOCAL_SERVER | 0x40000, pythoncom.IID_IDispatch)
                    break
                except pywintypes.com_error as exc:
                    # Automation server may still be shutting down after reference release.
                    if exc.hresult != -2147221231 or attempt == 2:
                        raise
                    time.sleep(1 + attempt)
            mode = '32bit_local_server_activation_may_start_separate_instance'
        app = dynamic.Dispatch(obj)
        version = str(app.Version)
        directory = Path(app.ApplicationDirectory)
        if not version.startswith('21.0.1') or directory != EXPECTED_DIRECTORY:
            raise RuntimeError(f'Wrong LabVIEW instance: {version}, {directory}')
        self.app = app
        app._FlagAsMethod('GetVIReference')
        self.connection_mode = mode
        return app

    def vi(self, path):
        safe = test_vi(path)
        key = str(safe)
        if getattr(self,'watch_external_changes',False):
            import hashlib
            current=hashlib.sha256(safe.read_bytes()).hexdigest()
            if key in OBSERVED_HASHES and OBSERVED_HASHES[key]!=current:
                raise RuntimeError('EXTERNAL_CHANGE_REOPEN_REQUIRED: '+key)
            OBSERVED_HASHES[key]=current
        if key not in self.references:
            self.references[key] = self.connect().GetVIReference(key, '', False, 0)
        return self.references[key]

    def status(self):
        a = self.connect()
        return {'ok': True, 'version': a.Version, 'application': a.AppName,
                'application_directory': a.ApplicationDirectory,
                'connection_mode': self.connection_mode, 'python_bits': struct.calcsize('P') * 8,
                'production_instance_verified': False,
                'scope': 'Local development/test instance; not a verified production project connection.',
                'write_tools_enabled': False, 'scripting_bridge_available': False}

    def list_vis(self):
        a = self.connect()
        try:
            return {'ok': True, 'complete': True, 'scope': 'connected application instance only',
                    'source': 'AllVIsInMemory', 'vis': list(a.AllVIsInMemory)}
        except pywintypes.com_error as exc:
            return {'ok': True, 'complete': False, 'scope': 'exported VIs in connected instance only',
                    'source': 'ExportedVIs', 'vis': list(a.ExportedVIs),
                    'enumeration_error': error(exc),
                    'note': 'This does not enumerate the VIs open in other LabVIEW/project instances.'}

    def inspect_vi(self, vi_path):
        v = self.vi(vi_path)
        fields, errors = {}, {}
        for prop in ['Name', 'Path', 'Description', 'ExecState', 'FPWinOpen', 'Callees']:
            try:
                fields[prop] = getattr(v, prop)
            except Exception as exc:
                errors[prop] = error(exc)
        return {'ok': bool(fields), 'complete': not errors, 'properties': fields,
                'property_errors': errors, 'executed': False,
                'compilation_note': 'ExecState is not a full compiler error report.'}

    def list_subvis(self, vi_path):
        return {'ok': True, 'source': 'VirtualInstrument.Callees',
                'callees': list(self.vi(vi_path).Callees),
                'scope': 'Direct callees reported by LabVIEW; dynamic runtime targets are not guaranteed.'}

    def get_vi_dependencies(self, vi_path):
        v = self.vi(vi_path)
        v._FlagAsMethod('GetVIDependencies')
        names = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_VARIANT, None)
        paths = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_VARIANT, None)
        v.GetVIDependencies(names, paths, True, False, True, False, True, True,
                            False, True, True, True, True, True, True, False)
        return {'ok': True, 'source': 'GetVIDependencies',
                'names': list(names.value or ()), 'paths': list(paths.value or ()),
                'scope': 'VI dependencies only; no DLLs or libraries, diagram loading disabled.'}

    def export(self, vi_path):
        v = self.vi(vi_path)
        v._FlagAsMethod('ExportVIStrings')
        with tempfile.TemporaryDirectory(prefix='labview-strings-') as folder:
            target = Path(folder) / 'strings.txt'
            v.ExportVIStrings(str(target), False, str(Path(folder) / 'export.log'), False, True)
            raw = target.read_bytes()
            if len(raw) > 4 * 1024 * 1024:
                raise ValueError('String export exceeds 4 MiB safety limit.')
            try:
                text = raw.decode('utf-8-sig')
                encoding = 'utf-8'
            except UnicodeDecodeError:
                text = raw.decode('mbcs')
                encoding = 'Windows active codepage (fallback)'
            return text, encoding

    def list_controls(self, vi_path):
        text, encoding = self.export(vi_path)
        return {'ok': True, 'complete': False, 'source': 'ExportVIStrings',
                'controls': parse_export(text), 'encoding': encoding,
                'limitations': ['Exported CONTROL records only, not live VI Server references.',
                    'Indicator/control direction, terminal types and values are unavailable.',
                    'Export ID is not a unique object identifier; duplicate labels are possible.']}

    def inspect_block_diagram(self, vi_path):
        text, encoding = self.export(vi_path)
        start = text.find('<BDCONTENT>')
        end = text.rfind('</BDCONTENT>')
        content = text[start + len('<BDCONTENT>'):end] if start >= 0 and end >= start else ''
        return {'ok': True, 'complete': False, 'source': 'ExportVIStrings',
                'diagram_strings': content[:65536], 'truncated': len(content) > 65536,
                'encoding': encoding, 'graph_available': False,
                'limitations': ['String export is not a graph of nodes, terminals or wires.',
                    'A VI Scripting helper is still required for structural inspection.']}

    def close(self):
        self.references.clear()
        self.app = None
        pythoncom.CoUninitialize()
