# LabVIEW MCP 2021

Experimental MCP bridge for LabVIEW 2021 SP1 (32-bit) on Windows using ActiveX and VI Scripting. **Source preview, not a fully functional release.**

## Setup
Clone this repository, then from its root in PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe server.py
```

Configure your MCP client to launch that Python executable with the absolute path to `server.py` as its argument (STDIO). LabVIEW must be installed locally. Use the checkout rather than a wheel because runtime resources are resolved relative to source files.

## Scope and limitations
The original local prototype includes inspection, graph editing, and execution of certified test VIs. This preview excludes binary VIs, NI examples, generated workers, private reports and third-party helper bundles. Advanced scripting requires locally provisioned helpers and fixtures; those operations are not ready to use in this checkout. Test manifests are empty and execution is not certified. Windows integration has not been retested for this preview. Do not use on production VIs or connected hardware.

## License
MIT for original project code. LabVIEW is separately licensed by NI. The original prototype uses Erdos Miller LV-Scripting (MIT) and NI scripting helpers, not bundled here.
