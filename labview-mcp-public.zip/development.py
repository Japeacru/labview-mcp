"""Development services: bounded inspection, catalog, impact analysis and certified fixtures."""
import json,math,time,hashlib
from pathlib import Path
from security import ROOT,digest
from policy import test_vi

def category(name):
    for label,words in [('arrays',['array']),('clusters',['cluster','bundle']),('strings',['string','format','match']),
        ('communications',['udp','tcp','queue','notifier','event']),('files',['file','path']),
        ('timing',['wait','tick','time']),('errors',['error']),('structures',['loop','case','sequence']),
        ('boolean',['and','or','not','equal','select']),('references',['reference','variant','dvr'])]:
        if any(w in name.lower() for w in words):return label
    return 'mathematics' if name in ['Add','Subtract','Multiply','Divide','Square Root','Max & Min'] else 'other'

class DevelopmentServices:
 def export_image(self,vi_path,surface='diagram'):
    p=test_vi(vi_path)
    if surface not in ['diagram','panel']:raise ValueError('surface must be diagram or panel')
    from native_images import png_bytes
    member='Block Diagram:Get Image Scaled' if surface=='diagram' else 'Front Panel:Get Image Scaled'
    result=self.engine().invoke('VI',member,self.engine().vi(str(p)),**{'Maximum Width':1600,'Maximum Height':1200})
    png,size=png_bytes(result['Image Data']);folder=ROOT/'artifacts';folder.mkdir(exist_ok=True)
    output=folder/f'{p.stem}-{digest(p)[:12]}-{surface}.png';output.write_bytes(png)
    return {'ok':True,'path':str(output),'size':size,'source':'LabVIEW VI Server native pixmap API','desktop_capture':False,
        'limitation':'Hidden panel images may not reflect runtime value updates; no window is opened.'}
 def recover_session(self,confirm_revert=False):
    from session_guard import recover
    return recover(self,confirm_revert)
 def project_inventory(self,project_path,offset=0,limit=50):
    from project_analysis import index_project
    if offset<0 or not 1<=limit<=200:raise ValueError('Invalid pagination')
    result=index_project(project_path);items=result.pop('items');vis=result.pop('vis')
    return result|{'total':len(items),'vi_count':len(vis),'items':items[offset:offset+limit],
        'next_offset':offset+limit if offset+limit<len(items) else None}
 def search_project(self,query,offset=0,limit=50):
    from project_analysis import semantic_search
    return semantic_search(query,offset,limit)
 def catalog(self,query='',category_filter=None,name=None,offset=0,limit=25):
    if offset<0 or not 1<=limit<=100:raise ValueError('Invalid catalog pagination')
    base=ROOT/'engine/runtime/vendor/lv-scripting-f7a14bd02f2c7c1fb062201657568a2ea6e0b7f6/source/library'
    entries={p.stem[7:]:{'name':p.stem[7:],'category':category(p.stem[7:]),'creator_helper':str(p),
        'verification':'discovered helper; creation not verified','creation_id':None,'terminals':None} for p in base.glob('Create *.vi')}
    styles=ROOT/'engine/style-catalog.json'
    if styles.exists():
        for label,code in json.loads(styles.read_text()).items():
            entries.setdefault(label,{'name':label,'category':category(label),'installed_style_id':code,
                'verification':'discovered in installed RingConstant.Strings And Values[]; not creation/execution verified',
                'creation_id':None,'terminals':None})
    verified=ROOT/'engine/catalog-verified.json'
    if verified.exists():entries.update(json.loads(verified.read_text()))
    if name is not None:
        if name not in entries:raise ValueError('Unknown catalog node')
        return {'ok':True,'definition':entries[name]}
    rows=[v for k,v in sorted(entries.items()) if query.casefold() in k.casefold() and (category_filter is None or v['category']==category_filter)]
    return {'ok':True,'nodes':rows[offset:offset+limit],'categories':sorted({v['category'] for v in entries.values()}),'total':len(rows),
        'next_offset':offset+limit if offset+limit<len(rows) else None,'complete':False}
 def supported_datatypes(self):
    catalog=json.loads((ROOT/'engine/catalog-verified.json').read_text());types={}
    for entry in catalog.values():
        for terminal in entry.get('terminals',[]):
            data=terminal.get('type',{});name=data.get('labview_type')
            if name:types.setdefault(name,{'name':name,'native_xml_read_verified':True,'example':data,'creation_execution_for_all_shapes':False})
    return {'ok':True,'complete':False,'types':list(types.values()),'limitations':['Typedef identity and all dimensions/shapes are not universally verified.']}
 def inspect_section(self,vi_path,section='summary',offset=0,limit=50,diagram_id=None,class_filter=None,query=None):
    p=test_vi(vi_path)
    if offset<0 or not 1<=limit<=200:raise ValueError('Invalid pagination')
    v=self.vi(str(p))
    if v.VIModificationBitSet:raise ValueError('Unsaved external changes: cache inspection refused')
    sha=digest(p);folder=ROOT/'cache';folder.mkdir(exist_ok=True)
    artifact=folder/(hashlib.sha256((str(p)+sha+'schema3').encode()).hexdigest()+'.json')
    hit=artifact.exists()
    if hit:g=json.loads(artifact.read_text())
    else:
        g=self.engine().inspect(str(p));g['_disk_sha256']=sha;artifact.write_text(json.dumps(g,indent=2,default=str))
    if section=='summary':data={'counts':{k:len(g.get(k,[])) for k in ['nodes','controls','terminals','wires','diagrams','tunnels','constants']},
        'coverage':g.get('coverage'),'dependencies':self.list_subvis(str(p))}
    else:
        if section not in ['nodes','controls','terminals','wires','diagrams','constants','tunnels','structures']:raise ValueError('Unknown section')
        rows=g.get(section,[]);rows=list(rows.values()) if isinstance(rows,dict) else rows
        if diagram_id is not None:rows=[x for x in rows if x.get('owner_id')==str(diagram_id)]
        if class_filter is not None:rows=[x for x in rows if x.get('class')==class_filter]
        if query:rows=[x for x in rows if query.casefold() in json.dumps(x).casefold()]
        data={'items':rows[offset:offset+limit],'total':len(rows),'offset':offset,'next_offset':offset+limit if offset+limit<len(rows) else None}
    return {'ok':True,'complete':False,'sha256':sha,'cache_hit':hit,'artifact':str(artifact),'section':section,**data}
 def impact(self,vi_path):
    p=test_vi(vi_path);v=self.vi(str(p))
    return {'ok':True,'path':str(p),'callers':list(v.Callers),'scope':'Loaded connected COM instance only',
        'complete':False,'warning':'Unloaded callers and dynamic calls require project indexing'}
 def run_fixture(self,vi_path,inputs,expected,timeout=5):
    p=test_vi(vi_path)
    manifest=ROOT/'config/functional-tests.json'
    cert=json.loads(manifest.read_text()).get(str(p.relative_to(ROOT))) if manifest.exists() else None
    if not cert or cert['sha256']!=digest(p):raise PermissionError('EXECUTION_DENIED: functional fixture is not certified')
    for path,sha in cert.get('dependencies',{}).items():
        dep=test_vi(path)
        if digest(dep)!=sha:raise PermissionError('EXECUTION_DENIED: dependency changed')
    if not .1<=timeout<=10 or timeout>cert.get('max_timeout',10):raise ValueError('Invalid timeout')
    if set(inputs)!=set(cert['inputs']) or set(expected)!=set(cert['outputs']):raise ValueError('Certified control names required')
    if len(json.dumps(inputs))>100000:raise ValueError('Inputs too large')
    v=self.vi(str(p))
    if v.ExecState!=1 or v.VIModificationBitSet:raise ValueError('VI must be clean and executable')
    v._FlagAsMethod('SetControlValue','GetControlValue','Run','Abort','ReinitializeAllToDefault')
    v.ReinitializeAllToDefault()
    for name,value in inputs.items():v.SetControlValue(name,tuple(value) if name in cert.get('cluster_inputs',[]) else value)
    v.Run(True);deadline=time.monotonic()+timeout
    while v.ExecState==2:
        if time.monotonic()>deadline:
            v.Abort();return {'ok':False,'code':'TIMEOUT_ABORTED','orderly_stop':False}
        time.sleep(.01)
    actual={name:v.GetControlValue(name) for name in expected}
    def eq(a,b):
        if isinstance(b,(list,tuple)):return isinstance(a,(list,tuple)) and len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
        if isinstance(b,(float,int)) and not isinstance(b,bool):return isinstance(a,(float,int)) and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9)
        return a==b
    return {'ok':all(eq(actual[k],expected[k]) for k in expected),'actual':actual,'expected':expected,'final_state':v.ExecState,
        'execution_scope':cert['purpose'],'hardware_allowed':False}
