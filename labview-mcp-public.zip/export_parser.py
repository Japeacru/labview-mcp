"""Parse NI's SGML-like string export (not well-formed XML)."""
from html.parser import HTMLParser

class ExportParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.content_depth = 0
        self.bd_depth = 0
        self.nodes = []
        self.controls = []
        self.stack = []

    def handle_starttag(self, tag, attrs):
        if tag == 'content':
            self.content_depth += 1
        if tag == 'bdcontent':
            self.bd_depth += 1
        if tag == 'node' and self.bd_depth:
            self.nodes.append(dict(attrs))
        if tag == 'control' and self.content_depth and not self.bd_depth:
            a = dict(attrs)
            index = len(self.controls)
            self.controls.append({'index': index, 'name': a.get('name'),
                'exported_type': a.get('type'), 'export_id': a.get('id'),
                'parent_index': self.stack[-1] if self.stack else None,
                'is_indicator': None})
            self.stack.append(index)

    def handle_endtag(self, tag):
        if tag == 'content':
            self.content_depth = max(0, self.content_depth - 1)
        elif tag == 'bdcontent':
            self.bd_depth = max(0, self.bd_depth - 1)
        elif tag == 'control' and self.stack:
            self.stack.pop()

def parse_export(text):
    parser = ExportParser()
    parser.feed(text)
    parser.close()
    return parser.controls
