"""Read-only XML project inventory plus explicit paginated VI inspection. Never runs VIs."""
import json,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote
from security import ROOT,digest
def index_project(project_path):
 p=Path(project_path)
 if not p.is_absolute() or p.suffix.lower()!='.lvproj':raise ValueError('Absolute .lvproj path required')
 p=p.resolve(strict=True)
 if p.stat().st_size>20_000_000:raise ValueError('Project XML too large')
 root=ET.parse(p).getroot();items=[]
 def visit(element,parent=None):
    if element.tag=='Item':
        url=element.get('URL');path=None;unresolved=None
        if url:
            if '://' in url or url.startswith('/<') or url.startswith('<'):unresolved='Virtual/remote resource path; not opened'
            else:
                candidate=Path(unquote(url))
                if not candidate.is_absolute():candidate=p.parent/candidate
                path=str(candidate.resolve())
        index=len(items);items.append({'index':index,'parent_index':parent,'name':element.get('Name'),
            'type':element.get('Type'),'url':url,'path':path,'exists':Path(path).exists() if path else None,'unresolved':unresolved})
        parent=index
    for child in element:visit(child,parent)
 visit(root)
 report={'ok':True,'complete':False,'path':str(p),'sha256':digest(p),'items':items,
    'vis':[x for x in items if x.get('path') and Path(x['path']).suffix.lower()=='.vi'],
    'libraries':[x for x in items if x.get('type') in ['Library','LVClass']],
    'typedef_candidates':[x for x in items if x.get('path') and Path(x['path']).suffix.lower()=='.ctl'],
    'executed':False,'limitations':['XML inventory does not resolve implicit/dynamic dependencies. Inspect VI sections incrementally.',
        'Main VI detection needs a call graph; XML membership alone is insufficient.']}
 folder=ROOT/'cache/projects';folder.mkdir(parents=True,exist_ok=True)
 artifact=folder/(hashlib.sha256(str(p).encode()).hexdigest()+'.json');artifact.write_text(json.dumps(report,indent=2))
 return report|{'artifact':str(artifact)}

def semantic_search(query,offset=0,limit=50):
 if offset<0 or not 1<=limit<=200:raise ValueError('Invalid pagination')
 concepts={'temperature':['temperature','temp','target','gain','power','coerced'],
    'temperatura':['temperature','temp','target','gain','power','coerced'],
    'udp':['udp','datagram'],'limit':['coerce','min','max','limit'],'límite':['coerce','min','max','limit'],
    'initialization':['open','init','initialize']}
 words=concepts.get(query.casefold(),[query.casefold()]);hits=[]
 for path in (ROOT/'cache').glob('*.json'):
    try:g=json.loads(path.read_text())
    except (OSError,ValueError):continue
    vi=g.get('vi')
    if not vi or not Path(vi).exists() or digest(Path(vi))!=g.get('_disk_sha256'):continue
    for section in ['nodes','controls','constants']:
        for row in g.get(section,[]):
            text=json.dumps(row).casefold()
            matched=[w for w in words if w in text]
            if matched:hits.append({'vi':vi,'section':section,'id':row['id'],'matched':matched,'object':row})
 return {'ok':True,'complete':False,'scope':'Hash-current cached inspected VIs only','method':'Explicit keyword/concept matching; not inferred algorithm proof',
    'total':len(hits),'items':hits[offset:offset+limit],'next_offset':offset+limit if offset+limit<len(hits) else None}
