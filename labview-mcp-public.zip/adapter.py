"""ActiveX subset. No desktop automation or binary VI patching."""
import json, shutil, time, uuid
from pathlib import Path
import pythoncom
from win32com.client import VARIANT
from backend import Backend
from export_parser import ExportParser
from policy import test_vi
from security import ROOT, require_certified, digest
from development import DevelopmentServices

class Adapter(DevelopmentServices,Backend):
    def __init__(self):
        super().__init__();self.watch_external_changes=True
    def engine(self):
        if not hasattr(self,'_scripting_engine'):
            from scripting import ScriptingEngine
            self._scripting_engine=ScriptingEngine()
        return self._scripting_engine

    def close(self):
        if hasattr(self,'_scripting_engine'):self._scripting_engine.release()
        super().close()

    def status(self):
        result=super().status()
        result['write_tools_enabled']=True
        result['write_scope']='test-vis; metadata and verified scalar arithmetic graph patches'
        result['scripting_bridge_available']=True
        return result

    def environment(self):
        return {'ok':True,'snapshot':json.loads((ROOT/'reports/environment.json').read_text()),
            'live_status_tool':'labview_get_status'}

    def inspect_vi(self, vi_path: str):
        result=super().inspect_vi(vi_path)
        result['inspection_scope']='basic metadata fields only; not full VI logic'
        result['graph_available']=False
        return result

    def capabilities(self):
        report=ROOT/'reports/verified.json'
        return {'ok': True, 'adapter': 'LabVIEW-21.0.1-32bit-ActiveX',
            'verification': json.loads(report.read_text()) if report.exists() else {},
            'scripting_acceptance': json.loads((ROOT/'phase2/reports/acceptance.json').read_text()).get('completed',False),
            'partial': {'inspection': 'Live nodes, terminals, wires, controls, UIDs, owners, diagrams, constants and tunnels; native type XML (DBL verified)',
                'list_vis': 'ExportedVIs fallback; connected automation instance only'},
            'unsupported': ['unrestricted_node_palette', 'complete_structure_semantics', 'all_type_families_verified',
                'full_compiler_diagnostics', 'hardware_execution', 'general_project_editing'],
            'mutation_scope': 'test-vis copies only', 'patch_actions': ['set_description','delete_object','disconnect_wire','add_node','connect'],
            'verified_node_palette':['Add','Multiply'],
            'post_acceptance_verified': {
                'saved_and_reopened_not_executed':['New VI','ForLoop','WhileLoop','shift registers','CaseStructure','wired SubVI','connector assignment','WaveformChart','panel label and position'],
                'evidence':'phase2/reports/extended-reopened.json',
                'exposed_by_graph_patch':False},
            'execution_scope': 'SHA256 certified arithmetic VIs only',
            'scripting_enabled_in_installation': True, 'general_scripting_bridge': True,
            'private_interfaces_used':False,'desktop_automation_used':False}

    def inspect_ir(self, vi_path: str):
        return self.engine().inspect(vi_path)

    def control_value(self, vi_path: str, name: str):
        v=self.vi(vi_path); v._FlagAsMethod('GetControlValue')
        return {'ok': True, 'name': name, 'value': v.GetControlValue(name)}

    def execution_state(self, vi_path: str):
        return {'ok': True, 'state': self.vi(vi_path).ExecState, 'full_compiler_diagnostics': False}

    def close_vi(self, vi_path: str):
        self.references.pop(str(test_vi(vi_path)), None)
        if hasattr(self,'_scripting_engine'):
            self._scripting_engine.release()
            del self._scripting_engine
        from backend import OBSERVED_HASHES
        OBSERVED_HASHES.pop(str(test_vi(vi_path)),None)
        return {'ok': True, 'released_owned_reference': True, 'unloaded_from_all_instances': False}

    def create_vi(self, output_path: str, operation: str):
        if operation=='blank':
            v=self.engine().new_from_scratch(Path(output_path))
            return {'ok':True,'path':str(v.Path),'created_from_template':False,
                'creation':'public New VI primitive followed by Save.Instrument inside G','execution_state':v.ExecState}
        if operation not in ['add','multiply']: raise ValueError('UNSUPPORTED_OPERATION: only array add/multiply')
        target=Path(output_path)
        if not target.is_absolute() or target.suffix.lower()!='.vi': raise ValueError('Absolute .vi path required')
        parent=target.parent.resolve(strict=True)
        if not parent.is_relative_to((ROOT/'test-vis').resolve()): raise PermissionError('Outside test-vis')
        target=parent/target.name
        if target.exists(): raise FileExistsError(target)
        template=ROOT/'test-vis'/('ArrayAdd.vit' if operation=='add' else 'ArrayMultiply.vit')
        require_certified(template)
        v=self.connect().GetVIReference(str(template),'',False,0)
        v._FlagAsMethod('SaveInstrument'); v.SaveInstrument(str(target),False,False)
        self.references[str(target)]=v
        return {'ok':True,'path':str(target),'operation':operation,'created_from_template':True,
            'interface':'Array -> Numeric; not separate A/B controls','sha256':digest(target)}

    def apply_patch(self, vi_path: str, operations: list[dict], dry_run: bool=True, expected_hash=None, confirm_destructive:bool=False):
        if any(op.get('action')!='set_description' for op in operations):
            return self.engine().patch(vi_path,operations,dry_run,expected_hash,confirm_destructive)
        p=test_vi(vi_path)
        if not operations or len(operations)>32: raise ValueError('Expected 1..32 operations')
        for op in operations:
            if set(op)!={'action','value'} or op['action']!='set_description':
                raise ValueError('UNSUPPORTED_OPERATION: only set_description is supported')
            if not isinstance(op['value'],str) or len(op['value'])>65536: raise ValueError('Invalid description')
        v=self.vi(str(p)); v._FlagAsMethod('GetLockState','SaveInstrument','Revert')
        cached=VARIANT(pythoncom.VT_BYREF|pythoncom.VT_BOOL,False)
        lock=v.GetLockState(cached)
        # Installed 2021 type library: invalid=0, unlocked=1, locked=2, password=3.
        if lock!=1: raise PermissionError(f'VI protected: lock state {lock}')
        if v.ExecState!=1 or v.FPWinOpen or v.Callers or v.VIModificationBitSet:
            raise ValueError('VI must be idle, clean, uncalled and panel closed')
        if dry_run: return {'ok':True,'dry_run':True,'operations':operations,'changed':False}
        folder=ROOT/'backups'/uuid.uuid4().hex; folder.mkdir(parents=True)
        backup=folder/p.name; shutil.copy2(p,backup)
        old=v.Description
        try:
            for op in operations: v.Description=op['value']
            v.SaveInstrument(str(p),False,False)
            from backend import acknowledge_save
            acknowledge_save(p)
            if v.Description!=operations[-1]['value']: raise RuntimeError('Verification failed')
        except Exception:
            v.Description=old; shutil.copy2(backup,p); v.Revert()
            raise
        return {'ok':True,'dry_run':False,'backup':str(backup),'operations':operations,'sha256':digest(p)}

    def run_test(self, vi_path: str, values: list[float], expected: float, timeout: float=5):
        p=test_vi(vi_path); require_certified(p)
        if not .1<=timeout<=20: raise ValueError('Timeout must be .1..20 seconds')
        if len(values)>10000: raise ValueError('Too many values')
        v=self.vi(str(p))
        if v.ExecState!=1: raise ValueError('VI is not idle and executable')
        if v.BDModificationBitSet or v.VIModificationBitSet:
            raise PermissionError('EXECUTION_DENIED: VI has unsaved modifications')
        v._FlagAsMethod('SetControlValue','GetControlValue','Run','Abort')
        labels={c['name'] for c in self.list_controls(str(p))['controls'] if c['parent_index'] is None}
        scalar=labels=={'A','B','C'}
        if scalar:
            if len(values)!=2:raise ValueError('Scalar arithmetic tests require exactly two inputs A and B')
            v.SetControlValue('A',values[0]);v.SetControlValue('B',values[1])
        else:v.SetControlValue('Array',VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8,values))
        v.Run(True); deadline=time.monotonic()+timeout
        while v.ExecState==2:
            if time.monotonic()>=deadline:
                v.Abort()
                return {'ok':False,'code':'TIMEOUT_ABORTED','orderly_stop':False}
            time.sleep(.02)
        actual=v.GetControlValue('C' if scalar else 'Numeric')
        import math
        return {'ok':math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12),
            'actual':actual,'expected':expected,'final_state':v.ExecState,'hardware_allowed':False}
