"""Serialized STA process. Only JSON on stdout; append-only operation audit."""
import json, sys, datetime
from adapter import Adapter
from backend import error
from security import ROOT
from session_guard import request_guard
OPERATIONS={'status','list_vis','inspect_vi','list_controls','list_subvis','inspect_block_diagram',
    'get_vi_dependencies','environment','capabilities','inspect_ir','control_value','execution_state',
    'close_vi','create_vi','apply_patch','run_test','catalog','inspect_section','impact','run_fixture','project_inventory','search_project','supported_datatypes','recover_session','export_image'}

def main():
    b=Adapter(); (ROOT/'logs').mkdir(exist_ok=True)
    try:
        for line in sys.stdin:
            request={}
            try:
                request=json.loads(line)
                if request['operation'] not in OPERATIONS: raise ValueError('Operation not allowed')
                with request_guard(request):result=getattr(b,request['operation'])(**request.get('arguments',{}))
            except Exception as exc: result={'ok':False,'error':error(exc)}
            record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'request':request,'result':result}
            with (ROOT/'logs/operations.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(record,default=str,ensure_ascii=True)+'\n')
            print(json.dumps(result,default=str,ensure_ascii=True,allow_nan=False),flush=True)
    finally: b.close()

if __name__=='__main__': main()
